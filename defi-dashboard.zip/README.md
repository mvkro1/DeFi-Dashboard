# DeFi Dashboard

A dashboard for tracking DeFi protocol metrics, visualizing price movements, and analyzing token data.